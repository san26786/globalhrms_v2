"use client";

import { useState } from "react";
import { DataTable } from "@/components/DataTable";

interface CommonTypeForm {
  typId?: number;
  typCd: string;
  typNm: string;
  viewNm: string;
  tableType: string;
}

const emptyForm: CommonTypeForm = { typCd: "", typNm: "", viewNm: "", tableType: "" };

export default function CommonTypePage() {
  const [form, setForm] = useState<CommonTypeForm>(emptyForm);
  const [mode, setMode] = useState<"add" | "edit">("add"); // mirrors $actionMode 0/1
  const [refreshToken, setRefreshToken] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const startEdit = (row: any) => {
    setMode("edit");
    setForm({
      typId: row.typId,
      typCd: row.typCd ?? "",
      typNm: row.typNm ?? "",
      viewNm: row.viewNm ?? "",
      tableType: row.tableType ?? "",
    });
  };

  const resetForm = () => {
    setMode("add");
    setForm(emptyForm);
    setError(null);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSaving(true);
    try {
      const url = mode === "edit" ? `/api/common-type/${form.typId}` : "/api/common-type";
      const method = mode === "edit" ? "PUT" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const json = await res.json();
      if (!res.ok) {
        setError(json.error ?? "Something went wrong");
        return;
      }
      resetForm();
      setRefreshToken((t) => t + 1);
    } finally {
      setSaving(false);
    }
  };

  const remove = async (row: any) => {
    if (!confirm(`Delete "${row.typNm}"?`)) return;
    const res = await fetch(`/api/common-type/${row.typId}`, { method: "DELETE" });
    if (res.ok) {
      setRefreshToken((t) => t + 1);
    } else {
      const json = await res.json();
      alert(json.error ?? "Could not delete record");
    }
  };

  return (
    <main className="max-w-4xl mx-auto py-10 px-6">
      <h1 className="text-2xl font-semibold text-neutral-900 mb-1">Common Type</h1>
      <p className="text-neutral-500 mb-8">Add, edit, and remove common type records.</p>

      <form
        onSubmit={submit}
        className="border border-neutral-200 rounded-lg p-5 mb-8 grid grid-cols-2 gap-4"
      >
        <div className="col-span-2 text-sm font-medium text-neutral-700">
          {mode === "edit" ? `Editing #${form.typId}` : "Add a new type"}
        </div>

        <label className="text-sm">
          Type Code
          <input
            required
            value={form.typCd}
            onChange={(e) => setForm({ ...form, typCd: e.target.value })}
            className="mt-1 w-full border border-neutral-300 rounded px-3 py-1.5"
          />
        </label>

        <label className="text-sm">
          Type Name
          <input
            required
            value={form.typNm}
            onChange={(e) => setForm({ ...form, typNm: e.target.value })}
            className="mt-1 w-full border border-neutral-300 rounded px-3 py-1.5"
          />
        </label>

        <label className="text-sm">
          View Name
          <input
            value={form.viewNm}
            onChange={(e) => setForm({ ...form, viewNm: e.target.value })}
            className="mt-1 w-full border border-neutral-300 rounded px-3 py-1.5"
          />
        </label>

        <label className="text-sm">
          Table Type
          <input
            value={form.tableType}
            onChange={(e) => setForm({ ...form, tableType: e.target.value })}
            className="mt-1 w-full border border-neutral-300 rounded px-3 py-1.5"
            placeholder="SYSTEM"
          />
        </label>

        {error && <div className="col-span-2 text-sm text-red-600">{error}</div>}

        <div className="col-span-2 flex gap-2">
          <button
            type="submit"
            disabled={saving}
            className="bg-neutral-900 text-white px-4 py-1.5 rounded text-sm disabled:opacity-50"
          >
            {saving ? "Saving…" : mode === "edit" ? "Save changes" : "Add type"}
          </button>
          {mode === "edit" && (
            <button
              type="button"
              onClick={resetForm}
              className="px-4 py-1.5 rounded text-sm border border-neutral-300"
            >
              Cancel
            </button>
          )}
        </div>
      </form>

      <DataTable
        model="common_type"
        refreshToken={refreshToken}
        columns={[
          { field: "typId", label: "ID" },
          { field: "typCd", label: "Code" },
          { field: "typNm", label: "Name" },
          { field: "viewNm", label: "View Name" },
          { field: "tableType", label: "Table Type" },
        ]}
        onEdit={startEdit}
        onDelete={remove}
      />
    </main>
  );
}
