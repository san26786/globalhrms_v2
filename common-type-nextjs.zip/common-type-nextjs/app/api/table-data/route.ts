import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

/**
 * Generic server-side table endpoint — the Next.js equivalent of
 * Common_c::getTableData(), which took a serialized "viewData" blob,
 * pulled draw/start/length/search/order/columns from the DataTables
 * POST body, and returned { draw, recordsTotal, recordsFiltered, data }.
 *
 * Instead of arbitrary raw SQL built from posted table/column names
 * (which was a SQL-injection footgun in the original), this maps a
 * whitelisted `model` key to a Prisma delegate. Add a table here to
 * expose it through this shared list endpoint.
 */
const MODEL_REGISTRY: Record<
  string,
  { delegate: any; searchableFields: string[]; defaultOrderField: string }
> = {
  common_type: {
    delegate: prisma.commonType,
    searchableFields: ["typCd", "typNm", "viewNm", "tableType"],
    defaultOrderField: "typId",
  },
  independent_mst: {
    delegate: prisma.independentMst,
    searchableFields: ["mstrCd", "mstrNm"],
    defaultOrderField: "mstrId",
  },
};

interface TableDataRequestBody {
  model: string; // e.g. "common_type" — replaces $pvs_objNm
  start?: number; // DataTables pagination offset
  length?: number; // page size, -1 for "all"
  search?: { value?: string };
  order?: { column: string; dir: "asc" | "desc" }[];
  filters?: Record<string, unknown>; // extra equality filters, e.g. { parentTypId: 5 }
  includeDeleted?: boolean;
  draw?: number;
}

export async function POST(req: NextRequest) {
  const body: TableDataRequestBody = await req.json();
  const { model, start = 0, length = 10, search, order, filters, includeDeleted, draw } = body;

  const config = MODEL_REGISTRY[model];
  if (!config) {
    return NextResponse.json(
      { error: `Unknown or unregistered model "${model}"` },
      { status: 400 }
    );
  }

  const baseWhere: Record<string, unknown> = { ...(filters ?? {}) };
  if (!includeDeleted) {
    baseWhere.isDeleted = false;
  }

  const searchValue = search?.value?.trim();
  const searchWhere =
    searchValue && config.searchableFields.length > 0
      ? {
          OR: config.searchableFields.map((field) => ({
            [field]: { contains: searchValue, mode: "insensitive" as const },
          })),
        }
      : {};

  const where = { AND: [baseWhere, searchWhere] };

  const orderBy =
    order && order.length > 0
      ? order.map((o) => ({ [o.column]: o.dir }))
      : [{ [config.defaultOrderField]: "asc" as const }];

  const take = length === -1 ? undefined : length;

  const [recordsTotal, recordsFiltered, data] = await Promise.all([
    config.delegate.count({ where: includeDeleted ? {} : { isDeleted: false } }),
    config.delegate.count({ where }),
    config.delegate.findMany({
      where,
      orderBy,
      skip: start,
      take,
    }),
  ]);

  return NextResponse.json({
    draw: draw ?? 0,
    recordsTotal,
    recordsFiltered,
    data,
  });
}
