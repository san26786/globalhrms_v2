import { NextRequest, NextResponse } from "next/server";
import { hardDelete } from "@/lib/hardDelete";
import { hasDeletePermission } from "@/lib/permissions";

interface Params {
  params: { id: string };
}

// DELETE /api/common-type/:id/hard-delete
export async function DELETE(req: NextRequest, { params }: Params) {
  if (!(await hasDeletePermission(req))) {
    return NextResponse.json({ error: "You do not have delete permission" }, { status: 403 });
  }

  const typId = Number(params.id);
  try {
    const count = await hardDelete("common_type", [typId]);
    if (count === 0) {
      return NextResponse.json({ error: "Could not delete record" }, { status: 404 });
    }
    return NextResponse.json({ success: true, message: "Successfully Deleted" });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}
