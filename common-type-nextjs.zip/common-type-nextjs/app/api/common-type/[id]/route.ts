import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { softDelete } from "@/lib/softDelete";
import { hasDeletePermission, currentUsername } from "@/lib/permissions";

interface Params {
  params: { id: string };
}

// GET /api/common-type/:id
export async function GET(_req: NextRequest, { params }: Params) {
  const typId = Number(params.id);
  const item = await prisma.commonType.findUnique({ where: { typId } });
  if (!item || item.isDeleted) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  return NextResponse.json(item);
}

// PUT /api/common-type/:id — "Edit Common Type"
export async function PUT(req: NextRequest, { params }: Params) {
  const typId = Number(params.id);
  const body = await req.json();
  const { typCd, typNm, viewNm, parentTypId, tableType } = body;

  if (!typCd || !typNm) {
    return NextResponse.json(
      { error: "Type Code and Type Name are required" },
      { status: 400 }
    );
  }

  const username = await currentUsername(req);

  try {
    const updated = await prisma.commonType.update({
      where: { typId },
      data: {
        typCd,
        typNm,
        viewNm: viewNm ?? null,
        parentTypId: parentTypId ?? null,
        tableType: tableType ?? null,
        updatedBy: username,
      },
    });
    return NextResponse.json(updated);
  } catch {
    return NextResponse.json({ error: "Record not found" }, { status: 404 });
  }
}

// DELETE /api/common-type/:id — "Delete Common Type" (soft delete, default behavior
// in the original app; hard delete is a separate route below).
export async function DELETE(req: NextRequest, { params }: Params) {
  if (!(await hasDeletePermission(req))) {
    return NextResponse.json({ error: "You do not have delete permission" }, { status: 403 });
  }

  const typId = Number(params.id);
  try {
    const count = await softDelete("common_type", { TYP_ID: [typId] });
    if (count === 0) {
      return NextResponse.json({ error: "Could not delete record" }, { status: 404 });
    }
    return NextResponse.json({ success: true, message: "Successfully Deleted" });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}
