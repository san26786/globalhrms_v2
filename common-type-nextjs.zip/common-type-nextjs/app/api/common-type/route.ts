import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { currentUsername } from "@/lib/permissions";

// GET /api/common-type — plain list (non-paginated). For the DataTables-style
// paginated/searchable list used by the UI, see /api/table-data.
export async function GET() {
  const items = await prisma.commonType.findMany({
    where: { isDeleted: false },
    orderBy: { typId: "asc" },
  });
  return NextResponse.json(items);
}

// POST /api/common-type — "Add Common Type"
export async function POST(req: NextRequest) {
  const body = await req.json();
  const { typCd, typNm, viewNm, parentTypId, tableType } = body;

  if (!typCd || !typNm) {
    return NextResponse.json(
      { error: "Type Code and Type Name are required" },
      { status: 400 }
    );
  }

  const username = await currentUsername(req);

  const created = await prisma.commonType.create({
    data: {
      typCd,
      typNm,
      viewNm: viewNm ?? null,
      parentTypId: parentTypId ?? null,
      tableType: tableType ?? null,
      createdBy: username,
    },
  });

  return NextResponse.json(created, { status: 201 });
}
