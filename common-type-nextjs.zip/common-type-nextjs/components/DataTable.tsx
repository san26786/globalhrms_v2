"use client";

import { useEffect, useState, useCallback } from "react";

export interface DataTableColumn {
  field: string; // Prisma field name, e.g. "typCd"
  label: string; // column header
}

interface DataTableProps {
  model: string; // registered key in MODEL_REGISTRY on the server
  columns: DataTableColumn[];
  pageSize?: number;
  onEdit?: (row: any) => void;
  onDelete?: (row: any) => void;
  refreshToken?: number; // bump this from the parent to force a reload
}

export function DataTable({
  model,
  columns,
  pageSize = 10,
  onEdit,
  onDelete,
  refreshToken,
}: DataTableProps) {
  const [rows, setRows] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/table-data", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model,
          start: page * pageSize,
          length: pageSize,
          search: { value: search },
        }),
      });
      const json = await res.json();
      setRows(json.data ?? []);
      setTotal(json.recordsFiltered ?? 0);
    } finally {
      setLoading(false);
    }
  }, [model, page, pageSize, search]);

  useEffect(() => {
    load();
  }, [load, refreshToken]);

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <input
          value={search}
          onChange={(e) => {
            setPage(0);
            setSearch(e.target.value);
          }}
          placeholder="Search…"
          className="border border-neutral-300 rounded px-3 py-1.5 text-sm w-64 focus:outline-none focus:ring-2 focus:ring-neutral-400"
        />
        <span className="text-sm text-neutral-500">{total} record{total === 1 ? "" : "s"}</span>
      </div>

      <table className="w-full text-sm border-collapse">
        <thead>
          <tr className="border-b border-neutral-300 text-left">
            {columns.map((c) => (
              <th key={c.field} className="py-2 pr-4 font-medium text-neutral-600">
                {c.label}
              </th>
            ))}
            {(onEdit || onDelete) && <th className="py-2 pr-4" />}
          </tr>
        </thead>
        <tbody>
          {loading && (
            <tr>
              <td colSpan={columns.length + 1} className="py-6 text-center text-neutral-400">
                Loading…
              </td>
            </tr>
          )}
          {!loading && rows.length === 0 && (
            <tr>
              <td colSpan={columns.length + 1} className="py-6 text-center text-neutral-400">
                No records found
              </td>
            </tr>
          )}
          {!loading &&
            rows.map((row) => (
              <tr key={row.typId ?? row.mstrId} className="border-b border-neutral-100">
                {columns.map((c) => (
                  <td key={c.field} className="py-2 pr-4">
                    {String(row[c.field] ?? "")}
                  </td>
                ))}
                {(onEdit || onDelete) && (
                  <td className="py-2 pr-4 text-right whitespace-nowrap">
                    {onEdit && (
                      <button
                        onClick={() => onEdit(row)}
                        className="text-neutral-600 hover:text-neutral-900 mr-3"
                      >
                        Edit
                      </button>
                    )}
                    {onDelete && (
                      <button
                        onClick={() => onDelete(row)}
                        className="text-red-600 hover:text-red-800"
                      >
                        Delete
                      </button>
                    )}
                  </td>
                )}
              </tr>
            ))}
        </tbody>
      </table>

      <div className="flex items-center justify-end gap-2 mt-3 text-sm">
        <button
          disabled={page === 0}
          onClick={() => setPage((p) => Math.max(0, p - 1))}
          className="px-2 py-1 border border-neutral-300 rounded disabled:opacity-40"
        >
          Prev
        </button>
        <span className="text-neutral-500">
          Page {page + 1} of {totalPages}
        </span>
        <button
          disabled={page + 1 >= totalPages}
          onClick={() => setPage((p) => p + 1)}
          className="px-2 py-1 border border-neutral-300 rounded disabled:opacity-40"
        >
          Next
        </button>
      </div>
    </div>
  );
}
