import { prisma } from "./prisma";

const HARD_DELETABLE_MODELS: Record<string, any> = {
  common_type: prisma.commonType,
  independent_mst: prisma.independentMst,
};

const PRIMARY_KEY_FIELD: Record<string, string> = {
  common_type: "typId",
  independent_mst: "mstrId",
};

/**
 * Equivalent of Common_c::hardDelete($tableName, $primaryKey) using
 * $this->input->post('delCheckbox') as the id list.
 */
export async function hardDelete(tableName: string, ids: (string | number)[]) {
  const model = HARD_DELETABLE_MODELS[tableName];
  const pk = PRIMARY_KEY_FIELD[tableName];
  if (!model || !pk) {
    throw new Error(`No hard-delete mapping registered for table "${tableName}"`);
  }
  if (!ids || ids.length === 0) {
    throw new Error("Please select records to delete");
  }

  const result = await model.deleteMany({
    where: { [pk]: { in: ids } },
  });

  return result.count;
}
