import { prisma } from "./prisma";

/**
 * Maps a DB table name -> Prisma delegate, so this stays a generic
 * "soft delete any table" utility like the original
 * Common_c::softDelete($tableName, ...$params) / checkIfCustomMethodAvailable().
 *
 * Add an entry here whenever you want a table to support soft delete
 * through this shared endpoint.
 */
const SOFT_DELETABLE_MODELS: Record<string, any> = {
  common_type: prisma.commonType,
  independent_mst: prisma.independentMst,
};

export interface SoftDeleteWhereClause {
  [column: string]: (string | number)[];
}

/**
 * Equivalent of the original loop that built `$where[$column] = $ids`
 * from alternating (column, id) pairs, then called
 * $this->entity_obj_attrbt_m->softDelete($tableName, $where).
 */
export async function softDelete(tableName: string, where: SoftDeleteWhereClause) {
  const model = SOFT_DELETABLE_MODELS[tableName];
  if (!model) {
    throw new Error(`No soft-delete mapping registered for table "${tableName}"`);
  }
  if (!where || Object.keys(where).length === 0) {
    throw new Error("Please select records to delete");
  }

  // Build a Prisma `AND` of `{ column: { in: [...] } }` filters, same intent
  // as the original dynamic $where array.
  const AND = Object.entries(where).map(([column, ids]) => ({
    [toCamelCase(column)]: { in: ids },
  }));

  const result = await model.updateMany({
    where: { AND },
    data: { isDeleted: true },
  });

  return result.count; // mirrors $affected_rows
}

function toCamelCase(column: string) {
  // Best-effort mapping of DB-style column names (e.g. TYP_ID) to the
  // camelCase Prisma field names defined in schema.prisma (typId).
  return column
    .toLowerCase()
    .replace(/_([a-z0-9])/g, (_, c) => c.toUpperCase());
}
