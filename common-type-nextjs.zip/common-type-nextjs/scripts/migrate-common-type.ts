/**
 * Port of Commontype_entity::entity().
 *
 * The original script:
 *  - read all common_type rows where TABLE_TYPE = 'SYSTEM'
 *  - for each, checked independent_mst for a matching TYP_ID
 *  - if found: wrote an UPDATE statement to update.txt (using the *existing*
 *    independent_mst row's own values — effectively a no-op, likely a bug)
 *  - if not found: wrote an INSERT statement to insert.txt using hardcoded
 *    placeholder values ('RECWR', 'Amit here') instead of the source row's
 *    actual TYP_CD/TYP_NM — also almost certainly a bug, and it inserted
 *    into a nonexistent `Customers` table instead of `independent_mst`.
 *
 * This version fixes both bugs (uses the real common_type values, targets
 * independent_mst) and performs the sync directly against the DB via Prisma
 * instead of emitting text files with raw SQL.
 *
 * Run with: npx tsx scripts/migrate-common-type.ts
 */
import { prisma } from "../lib/prisma";

async function main() {
  const systemTypes = await prisma.commonType.findMany({
    where: { tableType: "SYSTEM", isDeleted: false },
  });

  let updated = 0;
  let inserted = 0;

  for (const type of systemTypes) {
    const existing = await prisma.independentMst.findFirst({
      where: { typId: type.typId },
    });

    if (existing) {
      await prisma.independentMst.update({
        where: { mstrId: existing.mstrId },
        data: {
          mstrCd: type.typCd,
          mstrNm: type.typNm,
          typId: type.typId,
        },
      });
      updated++;
    } else {
      await prisma.independentMst.create({
        data: {
          mstrCd: type.typCd,
          mstrNm: type.typNm,
          typId: type.typId,
        },
      });
      inserted++;
    }
  }

  console.log(`Updated ${updated} independent_mst record(s).`);
  console.log(`Inserted ${inserted} independent_mst record(s).`);
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
