# Common Type — Next.js port of the CodeIgniter `Common_c` / `Commontype_entity` controllers

## What was ported, and how

| Original (CodeIgniter)                                      | Next.js equivalent                                             |
|---------------------------------------------------------------|------------------------------------------------------------------|
| `Common_c::getTableData()` (DataTables server-side processing) | `POST /api/table-data` (`app/api/table-data/route.ts`) — generic, whitelisted by a `model` key instead of raw table/column names from the client |
| Common Type add/edit/delete (stubbed out in the original constructor) | `app/api/common-type/route.ts` (list/create) + `app/api/common-type/[id]/route.ts` (get/update/soft-delete) |
| `Common_c::softDelete()` / `checkIfCustomMethodAvailable()`   | `lib/softDelete.ts` — a small per-table registry instead of dynamic model loading |
| `Common_c::hardDelete()`                                      | `lib/hardDelete.ts` + `app/api/common-type/[id]/hard-delete/route.ts` |
| `permission_validate_m->has_delete_permission()`               | `lib/permissions.ts` — **stub, wire to your real auth** |
| `Commontype_entity::entity()` (migration script that wrote SQL to `.txt` files) | `scripts/migrate-common-type.ts` — runs the sync directly against the DB via Prisma, and fixes two bugs in the original (see comments in the file) |
| CI views for list/add/edit forms                               | `app/common-type/page.tsx` + `components/DataTable.tsx` |

## What I had to infer (please verify against your real schema)

The original code never showed you the actual `common_type` / `independent_mst` table
definitions or the `entity_obj_attrbt_m` model — only how its methods were *called*.
`prisma/schema.prisma` reconstructs column names from variable names like
`$pvi_typeId`, `TYP_CD`, `MSTR_CD`, etc. **Before running migrations, check this against
your actual database** — either edit the schema to match, or run
`npx prisma db pull` against your existing DB and adjust the `@map`s in the app code.

## Setup

```bash
npm install
cp .env.example .env   # fill in DATABASE_URL
npx prisma generate
npx prisma migrate dev --name init   # or `prisma db pull` if the tables already exist
npm run dev
```

Visit `/common-type` for the CRUD UI.

## Notes / things worth deciding before going further

- **Soft vs hard delete**: `DELETE /api/common-type/:id` soft-deletes (sets `isDeleted`),
  matching the original's default `softDelete()` path. Hard delete is a separate,
  explicit route — don't wire a UI button to it without a confirmation step.
- **Auth**: `lib/permissions.ts` currently allows every delete. The original CI app's
  permission system (roles, session data) wasn't in the code you shared, so this needs
  a real implementation (NextAuth, a JWT, whatever you're using).
- **Registering more tables**: `MODEL_REGISTRY` in `app/api/table-data/route.ts` and the
  maps in `lib/softDelete.ts` / `lib/hardDelete.ts` are where you add other tables
  (e.g. the many other entities the original generic `entity_obj_attrbt_m` system
  handled) to reuse the same list/delete endpoints.
